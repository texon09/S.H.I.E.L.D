const API_BASES = ["http://localhost:8000", "https://s-h-i-e-l-d-ggtx.onrender.com"];

document.addEventListener("DOMContentLoaded", () => {
  const loader = document.getElementById("loader");
  const errorCard = document.getElementById("error-card");
  const resultCard = document.getElementById("result-card");
  
  const scannedUrlText = document.getElementById("scanned-url");
  const riskScoreText = document.getElementById("risk-score");
  const warningText = document.getElementById("warning-text");
  const verdictTier = document.getElementById("verdict-tier");
  const verdictBox = document.getElementById("verdict-box");
  const findingsList = document.getElementById("findings-list");
  
  const retryBtn = document.getElementById("retry-btn");
  const closeBtn = document.getElementById("close-btn");

  async function performScan() {
    loader.classList.remove("hidden");
    errorCard.classList.add("hidden");
    resultCard.classList.add("hidden");
    
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      if (!tabs || tabs.length === 0) {
        showError("Unable to locate active tab.");
        return;
      }
      
      const url = tabs[0].url;
      if (!url || !url.startsWith("http")) {
        showError("S.H.I.E.L.D. only analyzes HTTP/HTTPS addresses.");
        return;
      }
      
      scannedUrlText.textContent = url;
      
      let success = false;
      for (const apiBase of API_BASES) {
        try {
          const response = await fetch(`${apiBase}/api/scan`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ url: url })
          });
          
          if (response.ok) {
            const data = await response.json();
            renderResults(data);
            success = true;
            break;
          }
        } catch (err) {
          console.warn(`Failed to connect to ${apiBase}:`, err);
        }
      }
      
      if (!success) {
        showError("SYSTEM OFFLINE. Cannot connect to engine.");
      }
    });
  }

  function renderResults(data) {
    loader.classList.add("hidden");
    resultCard.classList.remove("hidden");
    
    riskScoreText.textContent = data.risk_score;
    
    let colorVar = '--safe-color';
    if (data.risk_tier === "safe") {
      colorVar = '--safe-color';
      verdictTier.textContent = "SAFE";
      warningText.textContent = "S.H.I.E.L.D. verified. Safe to visit.";
    } else if (data.risk_tier === "suspicious") {
      colorVar = '--suspicious-color';
      verdictTier.textContent = "CAUTION";
      warningText.textContent = "Minor threat indicators detected.";
    } else {
      colorVar = '--danger-color';
      verdictTier.textContent = "DANGER";
      warningText.textContent = "Strong phishing signals detected. Avoid.";
    }

    verdictBox.style.borderTopColor = `var(${colorVar})`;
    verdictTier.style.color = `var(${colorVar})`;
    riskScoreText.style.color = `var(${colorVar})`;

    findingsList.innerHTML = "";
    data.top_features.forEach(feat => {
      const isRisky = feat.direction === "risky";
      
      let plainLabel = feat.label.split(" (")[0]; 
      if (plainLabel.includes("obfuscating")) plainLabel = "Hidden characters";
      if (plainLabel.includes("URL length")) plainLabel = "Unusually long";
      if (plainLabel.includes("subdomains")) plainLabel = "Mimics real brands";
      if (plainLabel.includes("special characters")) plainLabel = "Suspicious symbols";
      if (plainLabel.includes("IP address")) plainLabel = "Uses raw numbers";

      const row = document.createElement("div");
      row.className = "finding-row";
      row.style.color = isRisky ? "var(--danger-color)" : "var(--safe-color)";
      
      row.innerHTML = `
        <span>${plainLabel}</span>
        <span>${isRisky ? "RISK" : "SAFE"}</span>
      `;
      findingsList.appendChild(row);
    });
  }

  function showError(msg) {
    loader.classList.add("hidden");
    resultCard.classList.add("hidden");
    errorCard.classList.remove("hidden");
    if (msg) document.getElementById("error-text").innerHTML = `[ ERROR ]<br><br>${msg}`;
  }

  retryBtn.addEventListener("click", performScan);
  closeBtn.addEventListener("click", () => window.close());

  performScan();
});
